<?php $__env->startSection('title'); ?>
list
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<!-- START PAGE CONTENT-->
<div class="page-content fade-in-up">

    <?php echo $__env->make('msg', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="ibox">
        <div class="ibox-head">
            <div class="ibox-title">Data Table</div>
        </div>
        <div class="ibox-body" style="overflow-x:auto;">
            <table class="table table-striped table-bordered table-hover" id="example-table" cellspacing="0"
                width="100%">
                <thead>
                    <tr>
                        <th>id</th>
                        <th>image</th>
                        <th>title</th>
                        <th>description</th>
                        <th>content</th>
                        <th>Edit</th>
                        <th>Delete</th>
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th>id</th>
                        <th>image</th>
                        <th>title</th>
                        <th>description</th>
                        <th>content</th>
                        <th>Edit</th>
                        <th>Delete</th>
                    </tr>
                </tfoot>
                <tbody>
                    <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($new->id); ?></td>
                        <td><img width="100px" src="upload/news/<?php echo e($new->image); ?>" alt=""></td>
                        <td><?php echo e($new->title); ?></td>
                        <td><?php echo e(substr($new->description,0,80)); ?> ...</td>
                        <td><?php echo e(substr($new->content,0,80)); ?> ...</td>
                        <td class="center"><i class="fa fa-pencil fa-fw"></i> <a
                        href="admin/news/edit/<?php echo e($new->id); ?>">Edit</a></td>
                        <td class="center"><i class="fa fa-trash-o  fa-fw"></i><a data-toggle="modal"
                                data-target="#myModal" href="admin/news/delete/<?php echo e($new->id); ?>"> Delete</a></td>
                                
                <!-- Modal -->
                <div class="modal fade" id="myModal" role="dialog" style="padding-top: 90px;">
                        <div class="modal-dialog">
    
                            <!-- Modal content-->
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                </div>
                                <div class="modal-body">
                                    <p>Xóa bài viết</p>
                                    <a class="btn btn-danger" href="admin/news/delete/<?php echo e($new->id); ?>">Xóa</a>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                </div>
                            </div>
    
                        </div>
                    </div>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>


            </table>
        </div>
    </div>
</div>
<!-- END PAGE CONTENT-->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<script src="assets/vendors/DataTables/datatables.min.js" type="text/javascript"></script>

<script type="text/javascript">
    $(function() {
        $('#example-table').DataTable({
            pageLength: 10,
            //"ajax": './assets/demo/data/table_data.json',
            /*"columns": [
                { "data": "name" },
                { "data": "office" },
                { "data": "extn" },
                { "data": "start_date" },
                { "data": "salary" }
            ]*/
        });
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('be.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gem\resources\views/be/news/list.blade.php ENDPATH**/ ?>