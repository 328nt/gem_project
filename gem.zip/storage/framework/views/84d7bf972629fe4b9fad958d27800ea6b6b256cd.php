<table>
    <thead>
    <tr>
        <th>id</th>
        <th>Name</th>
        <th>Firstname</th>
        <th>DoB</th>
        <th>Class</th>
        <th>Grade</th>
        <th>School</th>
        <th>Address</th>
        <th>Ward</th>
        <th>District</th>
        <th>Province</th>
        <th>Parentname</th>
        <th>Email</th>
        <th>Phone</th>
        <th>Name Contest</th>
        <th>link</th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $contestants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cont): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($cont->id); ?></td>
            <td><?php echo e($cont->name); ?></td>
            <td><?php echo e($cont->firstname); ?></td>
            <td><?php echo e($cont->dob); ?></td>
            <td><?php echo e($cont->class); ?></td>
            <td><?php echo e($cont->grade); ?></td>
            <td><?php echo e($cont->school); ?></td>
            <td><?php echo e($cont->address); ?></td>
            <td><?php echo e($cont->ward); ?></td>
            <td><?php echo e($cont->district); ?></td>
            <td><?php echo e($cont->province); ?></td>
            <td><?php echo e($cont->parentname); ?></td>
            <td><?php echo e($cont->email); ?></td>
            <td><?php echo e($cont->phone); ?></td>
            <td><?php echo e($cont->name_link); ?></td>
            <td><?php echo e($cont->link); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH C:\xampp\htdocs\gem\resources\views/be/exportform.blade.php ENDPATH**/ ?>