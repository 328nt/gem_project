<?php if(count($errors) > 0): ?>
<div class="alert alert-danger">
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo e($err); ?> <br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php endif; ?>

<?php if(session('msg')): ?>
<div class="alert alert-success">
    <?php echo e(session('msg')); ?>

</div>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\gem\resources\views/msg.blade.php ENDPATH**/ ?>