<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Contestants;
use Faker\Generator as Faker;

$factory->define(Contestants::class, function (Faker $faker) {
    return [
        //
    ];
});
